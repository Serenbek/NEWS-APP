import "./App.css";
import Login from "./components/Login/Login";
// import Layout from "./components/Layout/Layout";

function App() {
  return (
    <>
      <Login/>
    </>
  );
}

export default App;
