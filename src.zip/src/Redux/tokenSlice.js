import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  token: null,
};
